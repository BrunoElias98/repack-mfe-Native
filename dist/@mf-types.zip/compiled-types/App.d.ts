/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */
import React from 'react';
declare function App(): React.JSX.Element;
export default App;
